
'use client';
import Link from 'next/link';

export default function WelcomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <i className="ri-bank-line text-white text-xl"></i>
              </div>
              <h1 className="text-2xl font-['Pacifico'] text-blue-600">Capitol Global Bank</h1>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <div 
        className="relative min-h-[600px] flex items-center justify-center bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `linear-gradient(rgba(30, 64, 175, 0.85), rgba(59, 130, 246, 0.75)), url('https://readdy.ai/api/search-image?query=Modern%20luxury%20banking%20building%20with%20glass%20facade%20and%20professional%20corporate%20architecture%2C%20clean%20minimalist%20design%2C%20blue%20and%20white%20color%20scheme%2C%20professional%20lighting%2C%20contemporary%20financial%20district%20atmosphere%2C%20sophisticated%20business%20environment&width=1200&height=600&seq=banking_hero_bg&orientation=landscape')`
        }}
      >
        <div className="w-full max-w-6xl px-6">
          <div className="text-center text-white">
            <h2 className="text-5xl font-bold mb-6 leading-tight">
              Your Financial Future<br />
              <span className="text-blue-200">Starts Here</span>
            </h2>
            <p className="text-xl mb-8 text-blue-100 max-w-2xl mx-auto">
              Experience world-class banking services with Capitol Global Bank. 
              Secure, reliable, and designed for your financial success.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/login">
                <button className="bg-white text-blue-600 px-8 py-4 rounded-lg font-semibold text-lg hover:bg-blue-50 transition-colors cursor-pointer whitespace-nowrap">
                  Sign In to Your Account
                </button>
              </Link>
              <Link href="/signup">
                <button className="border-2 border-white text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-white hover:text-blue-600 transition-colors cursor-pointer whitespace-nowrap">
                  Open New Account
                </button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-16">
            <h3 className="text-4xl font-bold text-gray-800 mb-4">Why Choose Capitol Global Bank?</h3>
            <p className="text-xl text-gray-600">Trusted by millions worldwide for exceptional banking services</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center p-8 rounded-xl bg-blue-50 hover:bg-blue-100 transition-colors">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-shield-check-line text-white text-2xl"></i>
              </div>
              <h4 className="text-2xl font-semibold text-gray-800 mb-4">Bank-Level Security</h4>
              <p className="text-gray-600 leading-relaxed">
                Advanced encryption and multi-factor authentication protect your financial data 24/7
              </p>
            </div>

            <div className="text-center p-8 rounded-xl bg-green-50 hover:bg-green-100 transition-colors">
              <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-time-line text-white text-2xl"></i>
              </div>
              <h4 className="text-2xl font-semibold text-gray-800 mb-4">24/7 Access</h4>
              <p className="text-gray-600 leading-relaxed">
                Manage your accounts anytime, anywhere with our digital banking platform
              </p>
            </div>

            <div className="text-center p-8 rounded-xl bg-purple-50 hover:bg-purple-100 transition-colors">
              <div className="w-16 h-16 bg-purple-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-customer-service-2-line text-white text-2xl"></i>
              </div>
              <h4 className="text-2xl font-semibold text-gray-800 mb-4">Expert Support</h4>
              <p className="text-gray-600 leading-relaxed">
                Dedicated relationship managers and customer support when you need it most
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="py-20 bg-blue-600">
        <div className="max-w-4xl mx-auto text-center px-6">
          <h3 className="text-4xl font-bold text-white mb-6">Ready to Get Started?</h3>
          <p className="text-xl text-blue-100 mb-8">
            Join thousands of satisfied customers who trust Capitol Global Bank with their financial future
          </p>
          <Link href="/login">
            <button className="bg-white text-blue-600 px-10 py-4 rounded-lg font-semibold text-lg hover:bg-blue-50 transition-colors cursor-pointer whitespace-nowrap">
              Access Your Account Now
            </button>
          </Link>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-12">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <i className="ri-bank-line text-white"></i>
                </div>
                <h5 className="text-xl font-['Pacifico'] text-blue-400">Capitol Global</h5>
              </div>
              <p className="text-gray-400 leading-relaxed">
                Your trusted financial partner for a secure and prosperous future.
              </p>
            </div>

            <div>
              <h6 className="font-semibold mb-4">Services</h6>
              <ul className="space-y-2 text-gray-400">
                <li className="cursor-pointer hover:text-white transition-colors">Personal Banking</li>
                <li className="cursor-pointer hover:text-white transition-colors">Business Banking</li>
                <li className="cursor-pointer hover:text-white transition-colors">Investment Services</li>
                <li className="cursor-pointer hover:text-white transition-colors">Loans & Mortgages</li>
              </ul>
            </div>

            <div>
              <h6 className="font-semibold mb-4">Support</h6>
              <ul className="space-y-2 text-gray-400">
                <li className="cursor-pointer hover:text-white transition-colors">Help Center</li>
                <li className="cursor-pointer hover:text-white transition-colors">Contact Us</li>
                <li className="cursor-pointer hover:text-white transition-colors">Security Center</li>
                <li className="cursor-pointer hover:text-white transition-colors">Privacy Policy</li>
              </ul>
            </div>

            <div>
              <h6 className="font-semibold mb-4">Contact</h6>
              <ul className="space-y-2 text-gray-400">
                <li>1-800-CAPITOL</li>
                <li>support@capitolglobal.com</li>
                <li>Available 24/7</li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Capitol Global Bank. All rights reserved. Member FDIC.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
