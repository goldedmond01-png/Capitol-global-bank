
'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

export default function DashboardPage() {
  const [isLoading, setIsLoading] = useState(true);
  const [username, setUsername] = useState('');
  const [showSendMoneyModal, setShowSendMoneyModal] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [sendAmount, setSendAmount] = useState('');
  const [recipientAccount, setRecipientAccount] = useState('');
  const [description, setDescription] = useState('');
  const [authCode, setAuthCode] = useState('');
  const [showSuccess, setShowSuccess] = useState(false);
  const [pendingTransfer, setPendingTransfer] = useState<any>(null);
  const [hideBalances, setHideBalances] = useState(false);
  const router = useRouter();

  const accountBalance = 30000000;
  const withdrawableBalance = 29078643;
  const accountOfficerEmail = "jenniferroger156@gmail.com";

  useEffect(() => {
    const isLoggedIn = localStorage.getItem('isLoggedIn');
    const storedUsername = localStorage.getItem('username');

    if (!isLoggedIn || isLoggedIn !== 'true') {
      router.push('/login');
      return;
    }

    if (storedUsername) {
      setUsername(storedUsername);
    }

    setIsLoading(false);
  }, [router]);

  const handleLogout = () => {
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('username');
    router.push('/welcome');
  };

  const formatCurrency = (amount: number) => {
    if (hideBalances) {
      return '••••••••';
    }
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  const toggleBalanceVisibility = () => {
    setHideBalances(!hideBalances);
  };

  const handleSendMoney = () => {
    setShowSendMoneyModal(true);
  };

  const handleSendSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (sendAmount && recipientAccount) {
      // Store the transfer details and show authorization modal
      setPendingTransfer({
        amount: sendAmount,
        recipient: recipientAccount,
        description: description
      });
      setShowSendMoneyModal(false);
      setShowAuthModal(true);
    }
  };

  const handleAuthSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (authCode.trim()) {
      // Process the transfer
      setShowAuthModal(false);
      setShowSuccess(true);

      // Clear all form data
      setSendAmount('');
      setRecipientAccount('');
      setDescription('');
      setAuthCode('');
      setPendingTransfer(null);

      setTimeout(() => setShowSuccess(false), 3000);
    }
  };

  const closeSendMoneyModal = () => {
    setShowSendMoneyModal(false);
    setSendAmount('');
    setRecipientAccount('');
    setDescription('');
  };

  const closeAuthModal = () => {
    setShowAuthModal(false);
    setAuthCode('');
    setPendingTransfer(null);
    // Return to send money modal
    setShowSendMoneyModal(true);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
          <span className="text-gray-600">Loading your account...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                  <i className="ri-bank-line text-white text-xl"></i>
                </div>
                <h1 className="text-2xl font-[\\\'Pacifico\\\'] text-blue-600">Capitol Global</h1>
              </div>
              <nav className="hidden md:flex space-x-8">
                <button className="text-blue-600 font-medium border-b-2 border-blue-600 pb-1 cursor-pointer whitespace-nowrap">
                  Dashboard
                </button>
                <button className="text-gray-600 hover:text-gray-900 cursor-pointer whitespace-nowrap">
                  Accounts
                </button>
                <button className="text-gray-600 hover:text-gray-900 cursor-pointer whitespace-nowrap">
                  Transfer
                </button>
                <button className="text-gray-600 hover:text-gray-900 cursor-pointer whitespace-nowrap">
                  Payments
                </button>
                <button className="text-gray-600 hover:text-gray-900 cursor-pointer whitespace-nowrap">
                  Statements
                </button>
              </nav>
            </div>

            <div className="flex items-center space-x-4">
              <div className="hidden md:block text-right">
                <p className="text-sm text-gray-600">Welcome back,</p>
                <p className="font-semibold text-gray-900">{username}</p>
              </div>
              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                <i className="ri-user-line text-blue-600"></i>
              </div>
              <button
                onClick={handleLogout}
                className="text-gray-600 hover:text-red-600 cursor-pointer"
                title="Sign Out"
              >
                <i className="ri-logout-box-line text-xl"></i>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6">
        <div className="max-w-7xl mx-auto">
          {/* Welcome Section */}
          <div className="mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-2">Welcome back, {username}!</h2>
            <p className="text-gray-600">Here's an overview of your Capitol Global Bank accounts</p>
          </div>

          {/* Account Balance Cards */}
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            {/* Available Balance */}
            <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl p-6 text-white">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <div className="flex items-center space-x-3 mb-2">
                    <p className="text-blue-100 text-sm">Available Balance</p>
                    <button
                      onClick={toggleBalanceVisibility}
                      className="text-blue-100 hover:text-white cursor-pointer"
                      title={hideBalances ? 'Show Balance' : 'Hide Balance'}
                    >
                      <i className={hideBalances ? 'ri-eye-off-line' : 'ri-eye-line'}></i>
                    </button>
                  </div>
                  <h3 className="text-3xl font-bold">{formatCurrency(accountBalance)}</h3>
                </div>
                <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center">
                  <i className="ri-wallet-line text-2xl"></i>
                </div>
              </div>
              <div className="flex items-center space-x-2 text-blue-100 text-sm">
                <i className="ri-arrow-up-line"></i>
                <span>Account Number: ****7892</span>
              </div>
            </div>

            {/* Withdrawable Balance */}
            <div className="bg-gradient-to-br from-green-600 to-green-700 rounded-xl p-6 text-white">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <div className="flex items-center space-x-3 mb-2">
                    <p className="text-green-100 text-sm">Withdrawable Balance</p>
                    <button
                      onClick={toggleBalanceVisibility}
                      className="text-green-100 hover:text-white cursor-pointer"
                      title={hideBalances ? 'Show Balance' : 'Hide Balance'}
                    >
                      <i className={hideBalances ? 'ri-eye-off-line' : 'ri-eye-line'}></i>
                    </button>
                  </div>
                  <h3 className="text-3xl font-bold">{formatCurrency(withdrawableBalance)}</h3>
                </div>
                <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center">
                  <i className="ri-money-dollar-circle-line text-2xl"></i>
                </div>
              </div>
              <div className="flex items-center space-x-2 text-green-100 text-sm">
                <i className="ri-check-line"></i>
                <span>Available for withdrawal</span>
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
            <h3 className="text-xl font-semibold text-gray-900 mb-6">Quick Actions</h3>
            <div className="grid md:grid-cols-4 gap-4">
              <button
                onClick={handleSendMoney}
                className="flex flex-col items-center p-4 rounded-lg border border-gray-200 hover:border-blue-300 hover:bg-blue-50 transition-colors cursor-pointer"
              >
                <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center mb-3">
                  <i className="ri-send-plane-line text-white text-xl"></i>
                </div>
                <span className="font-medium text-gray-900 whitespace-nowrap">Send Money</span>
              </button>

              <button className="flex flex-col items-center p-4 rounded-lg border border-gray-200 hover:border-green-300 hover:bg-green-50 transition-colors cursor-pointer">
                <div className="w-12 h-12 bg-green-600 rounded-lg flex items-center justify-center mb-3">
                  <i className="ri-download-line text-white text-xl"></i>
                </div>
                <span className="font-medium text-gray-900 whitespace-nowrap">Receive Money</span>
              </button>

              <button className="flex flex-col items-center p-4 rounded-lg border border-gray-200 hover:border-purple-300 hover:bg-purple-50 transition-colors cursor-pointer">
                <div className="w-12 h-12 bg-purple-600 rounded-lg flex items-center justify-center mb-3">
                  <i className="ri-bill-line text-white text-xl"></i>
                </div>
                <span className="font-medium text-gray-900 whitespace-nowrap">Pay Bills</span>
              </button>

              <button className="flex flex-col items-center p-4 rounded-lg border border-gray-200 hover:border-orange-300 hover:bg-orange-50 transition-colors cursor-pointer">
                <div className="w-12 h-12 bg-orange-600 rounded-lg flex items-center justify-center mb-3">
                  <i className="ri-file-text-line text-white text-xl"></i>
                </div>
                <span className="font-medium text-gray-900 whitespace-nowrap">Statements</span>
              </button>
            </div>
          </div>

          {/* Recent Transactions */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold text-gray-900">Recent Transactions</h3>
              <button className="text-blue-600 hover:text-blue-700 font-medium cursor-pointer whitespace-nowrap">
                View All
              </button>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                <div className="flex items-center space-x-4">
                  <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                    <i className="ri-arrow-down-line text-green-600"></i>
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">Salary Deposit</p>
                    <p className="text-sm text-gray-600">Dec 28, 2024 • 2:30 PM</p>
                  </div>
                </div>
                <span className="text-lg font-semibold text-green-600">+$8,500.00</span>
              </div>

              <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                <div className="flex items-center space-x-4">
                  <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                    <i className="ri-arrow-up-line text-red-600"></i>
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">Online Purchase</p>
                    <p className="text-sm text-gray-600">Dec 27, 2024 • 5:45 PM</p>
                  </div>
                </div>
                <span className="text-lg font-semibold text-red-600">-$299.99</span>
              </div>

              <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                <div className="flex items-center space-x-4">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                    <i className="ri-exchange-line text-blue-600"></i>
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">Transfer to Savings</p>
                    <p className="text-sm text-gray-600">Dec 26, 2024 • 10:15 AM</p>
                  </div>
                </div>
                <span className="text-lg font-semibold text-blue-600">-$5,000.00</span>
              </div>

              <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                <div className="flex items-center space-x-4">
                  <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                    <i className="ri-refund-line text-purple-600"></i>
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">Refund - Amazon</p>
                    <p className="text-sm text-gray-600">Dec 25, 2024 • 3:20 PM</p>
                  </div>
                </div>
                <span className="text-lg font-semibold text-green-600">+$149.99</span>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Send Money Modal */}
      {showSendMoneyModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-semibold text-gray-900">Send Money</h3>
                <button
                  onClick={closeSendMoneyModal}
                  className="text-gray-400 hover:text-gray-600 cursor-pointer"
                >
                  <i className="ri-close-line text-xl"></i>
                </button>
              </div>

              <form onSubmit={handleSendSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Recipient Account Number
                  </label>
                  <input
                    type="text"
                    value={recipientAccount}
                    onChange={(e) => setRecipientAccount(e.target.value)}
                    placeholder="Enter account number"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Amount
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
                    <input
                      type="number"
                      value={sendAmount}
                      onChange={(e) => setSendAmount(e.target.value)}
                      placeholder="0.00"
                      className="w-full pl-8 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                      min="0.01"
                      step="0.01"
                      required
                    />
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    Available: {hideBalances ? '••••••••' : formatCurrency(withdrawableBalance)}
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Description (Optional)
                  </label>
                  <input
                    type="text"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="What's this for?"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                  />
                </div>

                <div className="flex space-x-3 pt-4">
                  <button
                    type="button"
                    onClick={closeSendMoneyModal}
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 cursor-pointer whitespace-nowrap"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 cursor-pointer whitespace-nowrap"
                  >
                    Continue
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Authorization Code Modal */}
      {showAuthModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center">
                    <i className="ri-shield-check-line text-red-600"></i>
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900">Security Authorization</h3>
                </div>
                <button
                  onClick={closeAuthModal}
                  className="text-gray-400 hover:text-gray-600 cursor-pointer"
                >
                  <i className="ri-close-line text-xl"></i>
                </button>
              </div>

              {/* Transfer Summary */}
              <div className="bg-gray-50 rounded-lg p-4 mb-6">
                <h4 className="font-medium text-gray-900 mb-2">Transfer Summary</h4>
                <div className="space-y-1 text-sm text-gray-600">
                  <div className="flex justify-between">
                    <span>Amount:</span>
                    <span className="font-medium text-gray-900">${pendingTransfer?.amount}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>To Account:</span>
                    <span className="font-medium text-gray-900">{pendingTransfer?.recipient}</span>
                  </div>
                  {pendingTransfer?.description && (
                    <div className="flex justify-between">
                      <span>Description:</span>
                      <span className="font-medium text-gray-900">{pendingTransfer.description}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Warning Message */}
              <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 mb-6">
                <div className="flex items-start space-x-3">
                  <i className="ri-alert-line text-orange-600 mt-0.5"></i>
                  <div>
                    <h4 className="text-sm font-medium text-orange-800 mb-1">Security Verification Required</h4>
                    <p className="text-sm text-orange-700">
                      For your protection, this transaction requires authorization code verification to proceed.
                    </p>
                  </div>
                </div>
              </div>

              <form onSubmit={handleAuthSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Authorization Code
                  </label>
                  <input
                    type="text"
                    value={authCode}
                    onChange={(e) => setAuthCode(e.target.value)}
                    placeholder="Enter 6-digit authorization code"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm text-center tracking-wider font-mono"
                    maxLength={6}
                    required
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Check your registered email or SMS for the code
                  </p>
                </div>

                <div className="flex space-x-3 pt-4">
                  <button
                    type="button"
                    onClick={closeAuthModal}
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 cursor-pointer whitespace-nowrap"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 cursor-pointer whitespace-nowrap"
                  >
                    Authorize Transfer
                  </button>
                </div>
              </form>

              {/* Contact Support */}
              <div className="mt-6 pt-6 border-t border-gray-200">
                <p className="text-sm text-gray-600 text-center mb-3">
                  Need help with authorization?
                </p>
                <div className="text-center">
                  <a
                    href={`mailto:${accountOfficerEmail}?subject=Authorization Code Request - Account ${username}&body=Hello,%0D%0A%0D%0AI need assistance with my authorization code for a transfer of $${pendingTransfer?.amount} to account ${pendingTransfer?.recipient}.%0D%0A%0D%0APlease help me complete this transaction.%0D%0A%0D%0AThank you.`}
                    className="inline-flex items-center space-x-2 text-blue-600 hover:text-blue-700 text-sm font-medium cursor-pointer"
                  >
                    <i className="ri-mail-line"></i>
                    <span>Contact Account Officer</span>
                  </a>
                  <p className="text-xs text-gray-500 mt-1">{accountOfficerEmail}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Success Message */}
      {showSuccess && (
        <div className="fixed top-4 right-4 bg-green-600 text-white px-6 py-3 rounded-lg shadow-lg z-50 flex items-center space-x-2">
          <i className="ri-check-line"></i>
          <span>Money sent successfully!</span>
        </div>
      )}
    </div>
  );
}
